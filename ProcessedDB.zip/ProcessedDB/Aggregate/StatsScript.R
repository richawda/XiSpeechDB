library(readr)
library(dgof)
library(ggplot2)
library(reshape2)
#Combine Wiki Data on Xi International Trips

setwd("~/Hard_Data_Truncated/XiTrips")

trip_df <- read.csv("table-1.csv")
trip_df <- trip_df[,2:3]



tempdf <-read.csv("table-8.csv")
tempdf <-tempdf[,2:3]
trip_df <- rbind(trip_df, tempdf )

trip_df$Dates <-gsub(".*"","",trip_df$Dates)


#write data
#write.csv(trip_df,"XiTrips.csv", row.names = FALSE)

#modify XiTrips csv to get dates that program missed--must have single data, 
#in paper used end date of trip
#use excel to convert dates to number type--start date is 01/01/1900
######################################################################

trip_df <- read.csv("XiTrips.csv")
trip_df <- trip_df[5] #select number type of dates
colnames(trip_df) <- c("TripDates") 


setwd("~/Hard_Data_Truncated")

df <- read.csv("StatsTests.csv")
dfdates <- df[,1:3]
colnames(dfdates)[1]<-"AggDates"
df <- df[,5:7]


trip_df[99:167,1] <- rep(NA, 69)
#df <- cbind(df, trip_df)#comment out to not include trip dates

#colnames(df)<- c("Aggregate","Confucius","Mencius","IntTripDates")

colnames(df)<- c("Aggregate","Confucius","Mencius")



df2<- df




df2melt <- na.omit(melt(df2))
colnames(df2melt)[1] <- "Thinker"
date.start <- as.Date('1900-01-01')
p0 = ggplot(df2melt, aes(x = value +date.start)) + 
  stat_ecdf(aes(group = Thinker, colour = Thinker)) + 
  labs(title = 'Empirical CDF of References', x ='Year', y= 'Cumulative Proportion of References' )
 

plot(p0)






###############################

#Null = distribution function which generated x (true distribution of x) discrete values is distribution y 
x <- df$Confucius
y <- ecdf(df$Aggregate)

ks.test(x,y,simulate.p.value=TRUE, B=2000)


x <- df$Mencius
y <- ecdf(df$Confucius)
ks.test(x,y,simulate.p.value=TRUE, B=2000)



x <- trip_df$TripDates
y <- ecdf(df$Aggregate)
ks.test(x,y,simulate.p.value=TRUE, B=2000)

#test is not exact, pvalues known to be conservative (Conover 1972), use simulated pvalues




