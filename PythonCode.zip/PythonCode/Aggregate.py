# -*- coding: utf-8 -*-
"""
Created on Fri Mar  4 23:05:09 2022

@author: RichardAnaconda
"""
import os
import csv 
files = []

def loop_directory(directory: str):
    for filename in os.listdir(directory):
        if filename.endswith('.csv'):
            file_directory = os.path.join(directory, filename)
            files.append(file_directory)
            


def agg(fil):
    with open(fil, mode = 'r', newline = '', encoding="utf-8") as file:
        read = csv.reader(file, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
        row_list = []
        for row in read:
            row_list.append(row)
        file.close()
    row_list.remove(row_list[0])
    print(fil, len(row_list))
    f = open('aggregate.csv', mode = 'a', newline = '', encoding='utf-8-sig')
    writ = csv.writer(f, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
    for row in row_list:
        writ.writerow(row)
    f.close()
    
    
loop_directory('Aggregate')

with open('aggregate.csv', mode = 'a', newline = '', encoding='utf-8-sig') as file:
    writ = csv.writer(file, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
    writ.writerow(['Title', 'Date', 'Source', 'Link'])
    file.close()
    
for fil in files:
    agg(fil)
    
    
    