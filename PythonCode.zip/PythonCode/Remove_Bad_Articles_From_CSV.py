# -*- coding: utf-8 -*-
"""
Created on Wed May  4 08:13:01 2022

@author: RichardAnaconda
"""

row_list = []
import os
import csv 
files = [] 

def loop_directory(directory: str):
    for filename in os.listdir(directory):
        if filename.endswith('.txt'):
            file_directory = os.path.join(directory, filename)
            files.append(file_directory)
       



with open('Sunzi/Sunzi2.csv', mode = 'r', newline = '', encoding="utf-8") as file:
        read = csv.reader(file, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
        for row in read:
            row_list.append(row)
        file.close()
header = row_list[0]
#reverse the csv file so that earliest date is at top

'''

row_list = row_list[1:] #remove header
row_list.reverse()


with open('Sunzi/Sunzi2.csv', mode = 'w', newline = '', encoding='utf-8-sig') as file:
        writ = csv.writer(file, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
        writ.writerow(header)
        for row in row_list:
            writ.writerow(row)
        file.close()
'''

loop_directory('Sunzi')
#files = files[1:]


i = 0
for fil in files:
    files[i] = fil.split('_')[1].split('.')[0]
    i = i + 1

#convert string to integer
files = list(map(int, files))

files.sort()
sublist = []
sublist = [row_list[i] for i in files]
print(sublist[0:5])


with open('Sunzi/Sunzi2.csv', mode = 'w', newline = '', encoding='utf-8-sig') as file:
        writ = csv.writer(file, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
        writ.writerow(header)
        for row in sublist:
            writ.writerow(row)
        file.close()
     
