# -*- coding: utf-8 -*-
"""
Created on Sat May  7 20:44:38 2022

@author: RichardAnaconda
"""

import os
import re
from collections import Counter
import numpy as np
import matplotlib.pyplot as plt

files = []
noncounts = []
compcounts = []

natsort = lambda s: [int(t) if t.isdigit() else t.lower() for t in re.split('(\d+)', s)]



def loop_directory(directory: str):
    for filename in os.listdir(directory):
        if filename.endswith('.txt'):
            file_directory = os.path.join(directory, filename)
            files.append(file_directory)

def grab_sent(fil):
    file = open(fil, 'r', encoding="utf-8")
    lines = file.readlines()
    #print(lines)
    file.close()
    full_text = lines[4:]
    full_text = ' '.join(full_text)
    cnt = full_text.count('孔子')
    if fil.endswith('COMP.txt'):
        compcounts.append(cnt)
    else: noncounts.append(cnt)


loop_directory('Kongzi')


files = sorted(files, key = natsort)

for fil in files:
    grab_sent(fil)

print('noncounts', noncounts)
print('compcounts', compcounts)


nonocc = Counter(noncounts)
nonocc.update({x:0 for x in [6]})
nonocc = dict(sorted(nonocc.items()))
compocc = Counter(compcounts)
compocc.update({x:0 for x in [4,6,7]})
compocc = dict(sorted(compocc.items()))

print('nonocc', nonocc)
print('compocc', compocc)

N = 7
nonvals = tuple(nonocc.values())[0:N]
compvals =  tuple(compocc.values())[0:N]


ind = np.arange(N) # the x locations for the groups
width = 0.35
fig = plt.figure()
ax = fig.add_axes([0,0,1,1])
ax.bar(ind, nonvals, width, color='r')
ax.bar(ind, compvals, width,bottom=nonvals, color='b')
ax.set_ylabel('Number of Speeches')
ax.set_xlabel('Number of References to Confucius Within Speech')
ax.set_title('In-Speech Frequency of References to Confucius')
ax.set_xticks(ind, ('1', '2', '3', '4', '5', '6','7'))
ax.set_yticks(np.arange(0, 90, 10))
ax.legend(labels=['Non-Comp', 'Comp'])
plt.show()





