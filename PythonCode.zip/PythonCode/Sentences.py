# -*- coding: utf-8 -*-
"""
Created on Thu Feb 10 06:10:52 2022

@author: Richard Anderson
"""
import os
import re




files = []
key_sents = []
key_fils = []
links = []
dates = []
titles = []

natsort = lambda s: [int(t) if t.isdigit() else t.lower() for t in re.split('(\d+)', s)]





def loop_directory(directory: str):
    for filename in os.listdir(directory):
        if filename.endswith('.txt'):
            file_directory = os.path.join(directory, filename)
            files.append(file_directory)

def grab_sent(fil):
    file = open(fil, 'r', encoding="utf-8")
    lines = file.readlines()
    #print(lines)
    file.close()
    #header = "".join(lines[0:3])
    full_text = lines[4:]
    full_text = ' '.join(full_text)
    full_text = full_text.split('。')
    #print(full_text)
    for sent in full_text:
        if sent.find('庄子') != -1:
           # print('yes：', fil, '\n', 'Sent:',sent)
            key_fils.append(fil.split('\\')[1][:-4])
            key_sents.append(sent+'\n')
            links.append(lines[0])
            titles.append(lines[1])
            dates.append(lines[2])
'''
def translate(key_sents):
    translator = Translator(service_urls=['translate.googleapis.com'])
    for sent in key_sents: 
        time.sleep(2)
        result = translator.translate(sent, src= 'zh-cn')
        line_by_line_trans.append(sent+"   "+result.text+'\n\n')
 '''

    
loop_directory('zhuangzi')
files = sorted(files, key = natsort)
#print(files)

#fil = 'Hanfeizi\Hanfeizi_6.txt'
#grab_sent(fil)



for fil in files:
   grab_sent(fil) 

print(links)

with open('C:/Users/RichardAnaconda/Documents/Hard_Data_Truncated/zhuangzi/ZhuangziSentences.txt', 'w', encoding="utf-8") as f:

   for k in range(len(key_sents)):
       f.write(key_fils[k])
       f.write('\n')
       f.write(titles[k])
       f.write(dates[k])
       f.write(links[k])
       f.write(key_sents[k])
       f.write('\n\n')
print('done')




