# -*- coding: utf-8 -*-
"""
Created on Wed May  4 10:24:54 2022

@author: RichardAnaconda
"""

import os 
import re
files =[]
compfil = []
excfil = []
newname = []

natsort = lambda s: [int(t) if t.isdigit() else t.lower() for t in re.split('(\d+)', s)]



def loop_directory(directory: str):
    for filename in os.listdir(directory):
        if filename.endswith('.txt'):
            file_directory = os.path.join(directory, filename)
            files.append(file_directory)
            
       
def identify_comp(fil):
    file = open(fil, 'r', encoding="utf-8")
    lines = file.readlines()
    #print(lines)
    file.close()
    full_text = lines[4:]
    full_text = ' '.join(full_text)
    full_text = full_text.split('。')
    counterdash = 0
    counterexc = 0
    #print(full_text)
    for sent in full_text:
        if sent.find('——') != -1 and re.search('(\d{1,2}月\d{1,2}日|\d{4}年\d{1,2}月)',sent):
            counterdash += 1
        if sent.find('——摘自习') != -1:
           counterexc += 1
        
    if counterdash>7:
        print(fil, 'is compfile')
        compfil.append(fil)
        
    elif counterexc>0:
        print(fil, 'is excerptfile')
        excfil.append(fil)
   
        
    file.close()
loop_directory('aggregatetextfiles')
files = sorted(files, key = natsort)
#print(files)

#fil = 'Hanfeizi\Hanfeizi_6.txt'
#grab_sent(fil)



for fil in files:
   identify_comp(fil) 
   
print(len(compfil))
print(len(excfil))
#print(compfil[0][:-4]+'_COMP.txt')


for fils in compfil:
    os.rename(fils, fils[:-4]+'_COMP.txt')
    
for fils in excfil:
    os.rename(fils, fils[:-4]+'_EXCE.txt')
    
'''

#remove naming


loop_directory('zhuangzi')
files = sorted(files, key = natsort)
print(files)

for fils in files:
    #print(fils)
    if fils.find('COMP') != -1:
        os.rename(fils, fils[:-13]+'_COMP.txt')  
      
for fils in files:   
    if fils.find('EXC') != -1:
        os.rename(fils, fils[:-8]+'_EXCE.txt')
  
'''