# -*- coding: utf-8 -*-
"""
Created on Tue Apr 19 08:34:07 2022

@author: RichardAnaconda
"""

import os
import re

natsort = lambda s: [int(t) if t.isdigit() else t.lower() for t in re.split('(\d+)', s)]

files = []
sus_files = []
def loop_directory(directory: str):
    for filename in os.listdir(directory):
        if filename.endswith('.txt'):
            file_directory = os.path.join(directory, filename)
            files.append(file_directory)
            
            

def grab_sent(fil):
    file = open(fil, 'r', encoding="utf-8")
    lines = file.readlines()
    #print(lines)
    file.close()
    full_text = lines[4:]
    full_text = ' '.join(full_text)
    full_text = full_text.split('。')
    #print(full_text)
    legit_ref = False 
    for sent in full_text:
        #print(sent)
        if (sent.find('孔子') != -1) and not ((sent.find('孔子学院') != -1) or (sent.find('孔子学堂') != -1)):
           legit_ref = True
           #print('yes:', sent)
           
    if legit_ref == False:
        sus_files.append(fil.split('\\')[1][:])
        
            
   
loop_directory('Kongzi')
files = sorted(files, key = natsort)
#print('Files:', files)
for fil in files:
   grab_sent(fil)

print(sus_files)


my_dir = 'Kongzi'
for fname in os.listdir(my_dir):
    if (fname in sus_files):
        os.remove(os.path.join(my_dir, fname))



#and not ((sent.find('孙子学院') != -1) or (sent.find('孙子学堂') != -1))
