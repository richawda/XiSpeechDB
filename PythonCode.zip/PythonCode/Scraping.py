# -*- coding: utf-8 -*-
"""
Created on Sun Oct  3 20:10:33 2021

@author: Richard Anderson
"""

import requests
from bs4 import BeautifulSoup
from selenium import webdriver 
from selenium.webdriver.common.keys import Keys
import pandas as pd
import csv
import time



driver = webdriver.Chrome('/Users/Richard Anderson/Downloads/chromedriver')


driver.get('http://jhsjk.people.cn/result?keywords=%E5%AD%99%E5%AD%90&isFuzzy=0')

href_list = []
title_list = []
date_list = []
source_list = []


html_list = driver.find_element_by_id("news_list")
items = html_list.find_elements_by_tag_name("li")
for k in range(len(items)):
    href_list.append(items[k].find_element_by_css_selector('a').get_attribute('href'))
    title_list.append(items[k].text.split('[')[0].split('\n')[0])
    source_list.append(items[k].text.split('[')[0].split('\n')[1].replace('来源：',''))
    date_list.append(items[k].text.split('[')[1][:-1])
    
for pg in range(2,4):
    next_button = '/html/body/div[6]/div[1]/div/span[%d]'%(pg)
    if driver.find_elements_by_xpath(next_button):
        print("page:", pg)
        click_next = driver.find_element_by_xpath(next_button)
        click_next.click()
        time.sleep(2.5)
        html_list = driver.find_element_by_id("news_list")
        items = html_list.find_elements_by_tag_name("li")
        #print('Item length:',len(items))
        for k in range(len(items)):
            href_list.append(items[k].find_element_by_css_selector('a').get_attribute('href'))
            title_list.append(items[k].text.split('[')[0].split('\n')[0])
            source_list.append(items[k].text.split('[')[0].split('\n')[1].replace('来源：',''))
            date_list.append(items[k].text.split('[')[1][:-1])
    else: break

 #span[4] is always next page after page 4
for pg in range(5,25):
    next_button = '/html/body/div[6]/div[1]/div/span[4]'
    if driver.find_elements_by_xpath(next_button):
        print("page:", pg)
        click_next = driver.find_element_by_xpath(next_button)
        click_next.click()
        time.sleep(2.5)
        html_list = driver.find_element_by_id("news_list")
        items = html_list.find_elements_by_tag_name("li")
        #print('Item length:',len(items))
        for k in range(len(items)):
            href_list.append(items[k].find_element_by_css_selector('a').get_attribute('href'))
            title_list.append(items[k].text.split('[')[0].split('\n')[0])
            source_list.append(items[k].text.split('[')[0].split('\n')[1].replace('来源：',''))
            date_list.append(items[k].text.split('[')[1][:-1])


driver.quit()

print(href_list)
print(title_list)
print(source_list)

    
with open('Sunzi.csv', mode = 'w', newline = '', encoding='utf-8-sig') as file:
        writ = csv.writer(file, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
        writ.writerow(['Title', 'Date','Source', 'Link'])
        for i in range(len(href_list)):
            #print(title_list[i])
            writ.writerow([title_list[i],date_list[i],source_list[i],href_list[i]])

        file.close()

    









#archive_url = 'http://jhsjk.people.cn/result?searchArea=0&keywords=%E9%9F%A9%E9%9D%9E&isFuzzy=0'

