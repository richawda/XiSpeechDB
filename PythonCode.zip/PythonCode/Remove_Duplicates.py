# -*- coding: utf-8 -*-
"""
Created on Thu Feb 17 16:52:27 2022

@author: RichardAnaconda
"""

import csv
from difflib import SequenceMatcher
import random
from datetime import datetime

title_list= []
row_list = []


def similar(a, b):
    return SequenceMatcher(None, a, b).ratio()


with open('aggregate.csv', mode = 'r', newline = '', encoding="utf-8") as file:
        read = csv.reader(file, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
        for row in read:
            row_list.append(row)
        file.close()
#print(row_list)
i = 0
index_list = []
header = row_list[0]
row_list = row_list[1:] #remove title
for k in row_list:
    print(k[1])

random.shuffle(row_list) #used to ensure no date bias in removal of duplicates


for i in range(len(row_list)):
    for k in range(i+1, len(row_list)):
        if similar(row_list[i][0],  row_list[k][0])>=.8:
            if row_list[k][0].find('全文') != -1:
                index_list.append(i)
            else: index_list.append(k)
            
print(index_list)

#for ind in index_list:
#    print(row_list[ind])
        
row_list2 = [row_list[k] for k, e in enumerate(row_list) if k not in index_list]

#sort back list by date



row_list2.sort(key=lambda date: datetime.strptime(date[1], "%m/%d/%Y"))


with open('aggregate2.csv', mode = 'w', newline = '', encoding='utf-8-sig') as file:
        writ = csv.writer(file, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
        writ.writerow(header)
        for row in row_list2:
            writ.writerow(row)
        file.close()

    















