# -*- coding: utf-8 -*-
"""
Created on Thu Jan 27 07:52:22 2022

@author: Richard Anderson
"""
from selenium import webdriver 
#from selenium.webdriver.common.keys import Keys
import csv
#import time

url_list = []
freq_count = []
title_list = []
date_list = []

with open('Aggregate2.csv', mode = 'r', newline = '', encoding="utf-8") as file:
        read = csv.reader(file, delimiter = ',', quotechar= '"', quoting = csv.QUOTE_MINIMAL )
        for row in read:
            url_list.append(row[3])
            title_list.append(row[0])
            date_list.append(row[1])
        file.close()

url_list.remove('Link')
title_list.remove('\ufeff\ufeffTitle')
date_list.remove('Date')
#print(url_list)
#print(title_list)

url_num = len(url_list)

url_num = 1
driver = webdriver.Chrome('C:/Users/RichardAnaconda/Downloads/chromedrivernew/chromedriver')

for link in url_list:
    texty = []
    stringy = ''
    driver.get(link)
    html_list = driver.find_element_by_css_selector('div.d2txt_con.clearfix')
    content = html_list.find_elements_by_tag_name('p')
    for k in range(len(content)):
        texty.append(content[k].text)
    stringy = stringy.join(texty)
    #print(stringy)
    #time.sleep(2.5)
    with open('C:/Users/RichardAnaconda/Documents/Hard_Data_Truncated/Aggregate/AggregateTextFiles/Agg_' + str(url_num).zfill(3) +'.txt', 'w', encoding="utf-8") as f:
        f.write(link)
        f.write('\n')
        f.write(title_list[url_list.index(link)])
        f.write('\n')
        f.write(date_list[url_list.index(link)])
        f.write('\n\n')
        f.write(stringy)
    url_num = url_num + 1
print('done!')





'''

link = 'http://jhsjk.people.cn/article/24145459'
texty = []
stringy = ''
driver.get(link)
html_list = driver.find_element_by_css_selector('div.d2txt_con.clearfix')
content = html_list.find_elements_by_tag_name('p')
for k in range(len(content)):
    texty.append(content[k].text)
driver.quit()
stringy = stringy.join(texty)
#freq_count.append(stringy.count('商鞅'))
#print(freq_count)
#print(stringy)


url_num = 1

with open('C:/Users/Richard Anderson/Documents/Thesis/Hard_Data/Mengzi/Mengzi_%d.txt'%(url_num), 'w', encoding="utf-8") as f:
        f.write(link)
        f.write('\n')
        f.write(title_list[url_list.index(link)])
        f.write('\n')
        f.write(date_list[url_list.index(link)])
        f.write('\n\n')
        f.write(stringy)
        url_num = url_num - 1


#freq_count.append(stringy.count('商鞅'))

'''
